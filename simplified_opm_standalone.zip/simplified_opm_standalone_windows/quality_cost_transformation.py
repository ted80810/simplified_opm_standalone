from gooey import Gooey, GooeyParser

def quality_cost_transformation(input_path, output_path):
    import tabula
    import re
    import pandas as pd

    # Path to the input PDF and output CSV
    input_pdf = input("Enter the path to the input PDF file: ie. input/MS_QualityCost_Aug_2022.pdf")
    output_csv_path = 'output/MS_QualityCost_Aug_2022_transformed.csv'

    # Extract tables from the PDF using tabula-py
    # Ensure Java is installed for tabula-py to work properly
    tables = tabula.read_pdf(f'{input_pdf}', stream=True, guess=False, pandas_options={'header': None},
                         columns=(147.39, 188.19,225.38,267.77,313.66,355.50,415.66,460.33,500.88))[0]

    tables.columns = ['MENU ITEM','AVG. PRICE','FOOD COST%','UNITS SOLD','FOOD COST$','UNITS WASTED','MENU WST FOOD COST$','RECIPE COST: FOOD','RECIPE COST: PAPER', 'RECIPE COST: TOTAL']

    # Convert numerical columns to appropriate types for consistency
    numerical_columns = [
        'AVG. PRICE', 'FOOD COST%', 'UNITS SOLD', 'FOOD COST$', 
        'UNITS WASTED', 'MENU WST FOOD COST$', 
        'RECIPE COST: FOOD', 'RECIPE COST: PAPER', 'RECIPE COST: TOTAL'
    ]

    for col in numerical_columns:
        tables[col] = pd.to_numeric(tables[col], errors='coerce')

    # Function to check if a string is a date range
    def is_date_range(text):
        date_range_pattern = r'\d{2}-\d{2}-\d{4} to \d{2}-\d{2}-\d{4}'
        return bool(re.match(date_range_pattern, text))

    # Dynamic logic to drop rows based on specified conditions:
    # 1. Drop rows where the first column contains words and numerical columns sum to zero.
    # 2. Drop rows where the first column contains a date range (e.g., '08-01-2022 to 08-31-2022').
    tables = tables[~(
        (tables['MENU ITEM'].str.match(r'\D+', na=False) & (tables[numerical_columns].sum(axis=1) == 0)) |
        (tables['MENU ITEM'].apply(lambda x: is_date_range(str(x))))
    )]

    # Save the cleaned and formatted DataFrame to a CSV file
    tables.to_csv(output_csv_path, index=False)

    print(f"Transformed CSV saved to: {output_csv_path}")
