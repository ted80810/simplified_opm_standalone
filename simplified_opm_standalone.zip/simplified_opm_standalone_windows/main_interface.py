from gooey import Gooey, GooeyParser
from inventorystats_transformation import inventorystats_transformation
from daily_expense_transformation import daily_expense_transformation
from quality_cost_transformation import quality_cost_transformation
from hours_register_transformation import hours_register_transformation
from non_product_inventory_sheet_transformation import non_product_inventory_sheet_transformation

# Dictionary mapping for function calls
function_map = {
    "inventorystats_transformation": inventorystats_transformation,
    "daily_expense_transformation": daily_expense_transformation,
    "quality_cost_transformation": quality_cost_transformation,
    "hours_register_transformation": hours_register_transformation,
    "non_product_inventory_sheet_transformation": non_product_inventory_sheet_transformation
}

@Gooey(program_name="PDF/CSV Processing Tool")
def main():
    parser = GooeyParser(description="Select the script and provide inputs")
    parser.add_argument('script_choice', choices=list(function_map.keys()), help="Choose a script to run")
    parser.add_argument('input_path', widget="FileChooser", help="Select the input file")
    parser.add_argument('output_path', widget="FileSaver", help="Select the output file path")
    args = parser.parse_args()

    # Call the selected function dynamically
    if args.script_choice in function_map:
        function_map[args.script_choice](args.input_path, args.output_path)

if __name__ == "__main__":
    main()
