#!/bin/bash

# Create a virtual environment named 'pdf_env'
python3 -m venv pdf_env

# Activate the virtual environment
source pdf_env/bin/activate

# Upgrade pip to the latest version
pip install --upgrade pip

# Install necessary Python libraries
pip install tabula-py pandas re os

# Deactivate the virtual environment
deactivate

echo "Virtual environment 'pdf_env' has been set up and the necessary libraries have been installed."
echo "To activate the virtual environment, use the command: source pdf_env/bin/activate"