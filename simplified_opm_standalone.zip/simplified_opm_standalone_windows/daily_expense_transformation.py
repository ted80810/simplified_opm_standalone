from gooey import Gooey, GooeyParser

def daily_expense_transformation(input_path, output_path):
    import tabula
    import pandas as pd
                        
    # Define file paths
    input_pdf_path = input("Enter the path to the input PDF file: ie. input/MS_DailyExpense_Aug_2024.pdf")
    output_csv_path = 'output/MS_DailyExpense_Aug_2024_transformed.csv'
                        
    # Manually specify column positions (adjust based on PDF format)
    columns_positions = [80, 124, 159, 209, 260, 294, 336, 369, 409, 444, 483, 521, 558]  # Adjust positions as needed
                        
    # Extract table using tabula with specified columns
    tables = tabula.read_pdf(
        input_pdf_path,
        pages='all',
        stream=True,
        guess=False,
        area=None,  # Specify if needed to limit the table extraction region
        columns=columns_positions,
        pandas_options={'header': None}
                        )
                        
        # Combine extracted tables if there are multiple pages
        if tables:
            df = pd.concat(tables, ignore_index=True)
        else:
            raise ValueError("No tables were extracted from the PDF.")
                        
        # Define the column names based on the provided CSV structure
        columns = ['DATE', 'A/R MISCE', 'PETTY CASH', 'CREDIT CARD', 'KRAVEN', 'CREW WAGES',
                                   'REGISTER REPAIRS', 'FOOD EXPENSE', 'KITCHEN EQUIP', 'MISC. EXPENSE',
                                   'OFFICE EXPENSE', 'PAPER EXPENSE', 'PROMO EXPENSE', 'TRAVEL EXPENSE']
                        
        # Check if the number of columns matches and set the column names
        if len(df.columns) == len(columns):
            df.columns = columns
        else:
            raise ValueError(f"Mismatch in the number of columns: Expected {len(columns)}, found {len(df.columns)}")
                        
        # Perform data cleaning if necessary
        df.replace(',', '', regex=True, inplace=True)
        df.replace('c', '', regex=True, inplace=True)
                        
        # Drop the first 5 rows dynamically
        df = df.iloc[5:].reset_index(drop=True)
                        
        # Save the DataFrame to a CSV file
        df.to_csv(output_csv_path, index=False)
                        
        print("PDF data has been successfully transformed and saved to CSV.")