from gooey import Gooey, GooeyParser

def inventorystats_transformation(input_path, output_path):
    import tabula
    import pandas as pd
    import re

    # Path to the input PDF and output CSV
    input_pdf = input("Enter the path to the input PDF file: ie. input/MS_InverntoryStat_Apr_2022.pdf")
    output_csv_path = 'output/MS_InventoryStat_Apr_2022_transformed.csv'

    # Function to dynamically read a PDF with flexible column handling
    def read_pdf_dynamic(input_pdf, page_number=3, header_option=None):

        # Read the PDF without hardcoding the column positions; use the 'guess' option for flexibility
        tables = tabula.read_pdf(
            input_pdf,
            stream=True,
            pages=page_number,
            guess=True,  # Let tabula guess the column positions for more flexibility
            pandas_options={'header': header_option}  # Adjust header dynamically
        )

        if not tables or len(tables) == 0:
            print("No tables found on the specified page.")
            return None

        # Choose the first table extracted, or adjust this logic if multiple tables are expected
        isr = tables[0]

        # Optional: Print columns and first few rows to verify structure
        print("Extracted columns:", isr.columns)
        print(isr.head())

        return isr

    # read pdf
    isr = read_pdf_dynamic(input_pdf, page_number=3, header_option=None)

    # Rename columns based on the structure for Inventory Stat (modify if needed)
    isr.columns = ['Wrin','Description','UOM','Initial Inv','Purchases','Trans+/-','Adjust','Account Adjust','Final Inv',
                  'Actual Usage (Inventory)','Cond','Raw Waste','Theorical Usage P.mix)','Amount in $ Stat +/-']

    # Function to dynamically drop rows based on a condition
    def drop_initial_rows(df, condition_func=None, max_rows_to_drop=10):
        """
        Drops rows from the top of a DataFrame based on a condition function.

        Parameters:
        - df (pd.DataFrame): The DataFrame to clean.
        - condition_func (function): A function that returns True for rows that should be dropped.
        - max_rows_to_drop (int): The maximum number of rows to check for dropping.

        Returns:
        - pd.DataFrame: The cleaned DataFrame.
        """
        # Apply the condition function to drop rows, if provided
        if condition_func:
            for i in range(min(max_rows_to_drop, len(df))):
                if condition_func(df.iloc[i]):
                    df = df.drop(index=i)
                else:
                    # Stop dropping rows if the condition is not met
                    break
        else:
            # Default: Drop the first `max_rows_to_drop` rows
            df = df.drop(index=range(max_rows_to_drop))

        # Reset the index after dropping rows
        df.reset_index(drop=True, inplace=True)

        return df

    # Drop initial rows
    isr = drop_initial_rows(isr, condition_func=lambda row: row.isnull().all(), max_rows_to_drop=10)

    # Save the cleaned and formatted DataFrame to a CSV file
    isr.to_csv(output_csv_path, index=False)

    print(f"Transformed CSV saved to: {output_csv_path}")

                
            
        
    
