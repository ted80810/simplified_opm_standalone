from gooey import Gooey, GooeyParser

@Gooey(program_name="PDF/CSV Processing Tool")
def main():
    parser = GooeyParser(description="Select the script and provide inputs")
    parser.add_argument('script_choice', choices=["'inventorystats_transformation'", "'daily_expense_transformation'", "'quality_cost_transformation'", "'hours_register_transformation'", "'non_product_inventory_sheet_transformation'"], help="Choose a script to run")
    parser.add_argument('input_path', widget="FileChooser", help="Select the input file")
    parser.add_argument('output_path', widget="FileSaver", help="Select the output file path")
    args = parser.parse_args()

    if args.script_choice == '{function_name}':
        {function_name}(args.input_path, args.output_path)

if __name__ == "__main__":
    main()
