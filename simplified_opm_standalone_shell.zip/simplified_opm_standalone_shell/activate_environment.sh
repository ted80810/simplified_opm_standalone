#!/bin/bash

# Activate the virtual environment
source opm_env/Scripts/activate