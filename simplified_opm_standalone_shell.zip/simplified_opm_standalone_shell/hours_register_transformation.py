import os
import pandas as pd

# Define relative paths for input and output directories
input_csv_path = input("Enter the path to the input csv file: ie. input/Hours_Register_Aug_2022.csv")
output_dir = 'output'
                    
# Ensure the output directory exists
if not os.path.exists(output_dir):
	os.makedirs(output_dir)
                    
# Load the original CSV file
input_file = input_csv_path
output_file = os.path.join(output_dir, 'Hours_Register_Aug_2022_transformed.csv')
                    
# Check if input file exists
if not os.path.exists(input_file):
	print(f"Input file '{input_file}' not found. Please place the file in the 'input' directory.")
else:
    # Step 1: Load CSV to find the start of data dynamically
    df = pd.read_csv(input_file, header=None)
    start_row = df[df[0] == 'CREW'].index[0] + 1
                        
    # Load the data starting from the actual data row
    data_df = pd.read_csv(input_file, skiprows=start_row)
                        
    # Step 2: Drop unnecessary columns
    data_df = data_df.loc[:, ~data_df.columns.str.contains('^Unnamed')]
                        
    # Step 3: Rename columns
    column_names = ['Employee Name', 'Employee Type', 'Store Number', 'Employee Number','NA', 'Regular', 'Other Reg', 'Time/Half', 'Double', 'Vac Allowance', 'Other','Sick', 'Other.1', 'Date']
    data_df.columns = column_names[:len(data_df.columns)]
                        
    # Step 4: Drop rows without 'Employee Name' and reset index
    data_df = data_df.dropna(subset=['Employee Name']).reset_index(drop=True)
                        
    # Save the transformed data to the output directory
    data_df.to_csv(output_file, index=False)
    print(f"Transformed file saved to '{output_file}'.")
                    
                
            
        
    
