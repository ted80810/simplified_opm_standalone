
import tabula
import pandas as pd

# Path to the input PDF and output CSV
input_pdf = input("Enter the path to the input PDF file: ie. input/MS_Non-Product_Aug_2022.pdf")
output_csv_path = 'output/MS_Non-Product_Aug_2022_transformed.csv'

# Extract tables from the PDF using tabula-py
# Note: Ensure Java is installed for tabula-py to work properly
tables = tabula.read_pdf(input_pdf, pages='all', multiple_tables=True, stream=True)

# Combine all extracted tables into a single DataFrame
combined_df = pd.concat(tables, ignore_index=True)

# Clean and process the DataFrame
combined_df = combined_df.dropna(how='all')  # Drop fully empty rows
combined_df.columns = [col.strip() for col in combined_df.columns]  # Strip whitespace from column headers

# Rename columns to match the target format
combined_df.columns = [
    'DATE', 'QUANTITY_1', 'AMOUNT_1', 'QUANTITY_2', 'AMOUNT_2', 
    'QUANTITY_3', 'AMOUNT_3', 'TOTAL IMPORT'
    ]

# Ensure numerical columns are converted properly
for col in combined_df.columns[1:]:
    combined_df[col] = pd.to_numeric(combined_df[col], errors='coerce')

# Replace NaNs with zeros for numerical consistency
combined_df = combined_df.fillna(0)

# Save the cleaned and formatted DataFrame to a CSV file
combined_df.to_csv(output_csv_path, index=False)

print(f"Transformed CSV saved to: {output_csv_path}")

        
    
