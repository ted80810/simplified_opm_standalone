How to Use the CSV Transformation Script README

Install Dependencies:
1. Open Bash Shell. This is call a Terminal on a Mac machine or Powershell on a Windows machine.
2. NOTE if you are running this code for the first time, go to step 3 and follow until step 6. If not, go to step 6. To run code in the bash window, type the given code after the colon and then press enter. 
3. Run this code in bash window: chmod +x setup_env.sh
4. Run this code in the bash window to setup a virtual environment: ./setup_env.sh
5. Activate the virtual environment: source pdf_env/bin/activate  # On macOS/Linux
./pdf_env/Scripts/activate     # On Windows
6. Run this code in bash window: pip install tabula-py pandas regex
7. Activate the virtual environment: source pdf_env/bin/activate  # On macOS/Linux
./pdf_env/Scripts/activate     # On Windows

How to run Transformation Script
1. Place your input CSV file or pdf file in the input folder ie. (`Hours_Register_Aug_2022.csv`) in the `input` folder.
2. Run the related transformation script in the bash window ie. (For Hours Register run this code in the bash window: python hours_register_transformation.py)
3. The transformed CSV file or pdf will be generated in the `output` folder ie. (`Hours_Register_Aug_2022_transformed.csv`).

# Requirements:
- Python 3.x
- pandas library (install with `pip install pandas`)
- tabula library (install with `pip install tabula`)